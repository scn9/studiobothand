/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'font', 'fr-ca', {
	fontSize: {
		label: 'Taille',
		voiceLabel: 'Taille',
		panelTitle: 'Taille'
	},
	label: 'Police',
	panelTitle: 'Police',
	voiceLabel: 'Police'
} );
