<div class="container pagination">
	<div class="row">
		<div class="previous span6">
			<p><?php previous_posts_link(); ?></p>
		</div>
		<div class="next span6">
			<p><?php next_posts_link(); ?></p>
		</div>   
	</div>
</div>